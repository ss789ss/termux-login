# TERMUX LOGIN SCRIPT (2.0)
##### Secure your Termux App with Password

<img src="https://i.ibb.co/1G42FbC/termux-login.png"> 

## [+] Installation & Usage
```
apt update
apt install git -y
git clone https://github.com/htr-tech/termux-login.git
cd termux-login
chmod +x *
sh install.sh
exit 
``` 
    
### or use Single Command
```
apt update && apt install git -y && git clone https://github.com/htr-tech/termux-login.git && cd termux-login && chmod +x * && sh install.sh
```
### Now go to Termux App & Set Username,Password AND Recovery Key

##### [+] Requirements
```Python 2.x```

#### [+] Features:
• Bug Fixed

• Parrot typing Shell Added


#### CREDITS:
    
    https://github.com/Udoy2/ 🤩
    https://github.com/TechnicalMujeeb/ 🤩
    
## [+] Find Me on :
#### Instagram : @tahmid.rayat
#### Facebook : tahmid.rayat.official
#### Github : htr-tech
